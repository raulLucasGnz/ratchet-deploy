//Cick Comprar
const botonComprar = document.getElementById("comprar");
botonComprar.addEventListener("click", function () {
  window.location.href = "https://buy.stripe.com/8wMdUh5hJbyR3GE6oo"; // Redirige a la pasarela de pago
});
